<?php

class QVideosContentPanel extends QPanel {

    public $dtrVideos;

    public $lstType;
    public $lstGame;
    public $lstStake;
    public $lstSite;
    public $lstTrainer;
    public $txtTag;
    public $btnTagSave;

    public function __construct($objParentObject, $strControlId = null){
        // Call the Parent
        try {
            parent::__construct($objParentObject, $strControlId);
        } catch (QCallerException $objExc) {
            $objExc->IncrementOffset();
            throw $objExc;
        }

        $this->Template = __VIEW_DIR__.'/videos/_QVideosContentPanel.tpl.php';

        $this->dtrVideos = new QDataRepeater($this);
        $this->dtrVideos->Paginator = new QPaginator($this);
        $this->dtrVideos->ItemsPerPage = 6;

        // Enable AJAX-based rerendering for the QDataRepeater
        $this->dtrVideos->UseAjax = true;

        // DataRepeaters use Templates to define how the repeated
        // item is rendered
        $this->dtrVideos->Template = __VIEW_DIR__.'/videos/_dtrVideosContentPanel.tpl.php';

        // Finally, we define the method that we run to bind the data source to the datarepeater
        $this->dtrVideos->SetDataBinder('dtrVideos_Bind',$this);
        $this->lstType_Create();
        $this->lstGame_Create();
        $this->lstStake_Create();
        $this->lstSite_Create();
        $this->lstTrainer_Create();
        $this->txtTag_Create();
        $this->btnTagSave_Create();


    }

    public function btnTagSave_Create(){
        $this->btnTagSave = new QButton($this);
        $this->btnTagSave->CssClass = 'drop-down-input';
        $this->btnTagSave->Text = QApplication::Translate('Buscar').'!';
        $this->btnTagSave->AddAction(new QClickEvent(), new QAjaxControlAction($this,'btnTagSave_Click'));
    }

    public function dtrVideos_Bind(){
        //$this->dtrComments->TotalItemCount = Blogtrainerscomments::CountByBlogtrainersId($this->intIdBlogTrainers);
        //tenia ,QQ::Clause($this->dtrComments->LimitClause) --> cuando se usaba paginador
        $objCondition = QQ::All();

        //Site is hardcoded to 1
        $this->lstSite->SelectedValue = 1;
        $objCondition = QQ::AndCondition($objCondition,QQ::Equal(QQN::Video()->VideositeId,$this->lstSite->SelectedValue));
        //set language id
        $objCondition = QQ::AndCondition($objCondition,QQ::Equal(QQN::Video()->LanguageId, $_SESSION['LanguageId']));
        //Set visible true
        $objCondition = QQ::AndCondition($objCondition,QQ::Equal(QQN::Video()->Visible, true));
        
        if ($this->lstType->SelectedValue){
            $objCondition = QQ::AndCondition($objCondition,QQ::Equal(QQN::Video()->VideotypeId, $this->lstType->SelectedValue));
        }
        if ($this->lstGame->SelectedValue){
            $objCondition = QQ::AndCondition($objCondition,QQ::Equal(QQN::Video()->VideogameId,$this->lstGame->SelectedValue));
        }
        if ($this->lstStake->SelectedValue){
            $objCondition = QQ::AndCondition($objCondition,QQ::Equal(QQN::Video()->VideostakeId,$this->lstStake->SelectedValue));
        }
        if ($this->lstTrainer->SelectedValue){
            $objCondition = QQ::AndCondition($objCondition,QQ::Equal(QQN::Video()->Trainer->Trainer->IdTrainer,$this->lstTrainer->SelectedValue));
        }
        if ($this->txtTag->Text){
            $objCondition = QQ::AndCondition($objCondition,QQ::Equal(QQN::Video()->VideotagAsTag->Videotag->Name,$this->txtTag->Text));
        }
        
        $this->dtrVideos->DataSource = Video::QueryArray($objCondition,QQ::Clause($this->dtrVideos->LimitClause));
        $this->dtrVideos->TotalItemCount = Video::QueryCount($objCondition);


    }

    public function txtTag_Create(){

        $objVideoTagsArray = Videotag::LoadAll();
        $autoCompleteItemsArray = array();
        foreach ($objVideoTagsArray as $objVideoTag) {
            $autoCompleteItemsArray[] = $objVideoTag->Name;
        }
        $this->txtTag = new QJavaScriptAutoCompleteTextBox($this, $autoCompleteItemsArray);
        $this->txtTag->Name = QApplication::Translate('Tag');
		//Como el enter se usa para el autocompletado, solo quiero que no me llame al buscador de arriba
        $this->txtTag->AddAction(new QEnterKeyEvent(), new QTerminateAction());
    }
    public function lstType_Create(){
        $this->lstType = new QListBox($this);
        $this->lstType->CssClass = 'drop-down-input';
        $this->lstType->Name = QApplication::Translate('Tipo');
        $this->lstType->Required = false;
        $objListItem = new QListItem(QApplication::Translate("Todos"), null);
        $this->lstType->AddItem($objListItem);
        $objTypeArray = Videotype::LoadAll();
        if ($objTypeArray) foreach ($objTypeArray as $objType) {
            $objListItem = new QListItem($objType->__toString(), $objType->IdVideotype);
            $this->lstType->AddItem($objListItem);
        }
        $this->lstType->AddAction(new QChangeEvent(), new QAjaxControlAction($this,'lstAll_Change'));

    }

    public function lstGame_Create(){
        $this->lstGame = new QListBox($this);
        $this->lstGame->CssClass = 'drop-down-input';
        $this->lstGame->Name = QApplication::Translate('Juego');
        $this->lstGame->Required = false;
        $objListItem = new QListItem(QApplication::Translate("Todos"), null);
        $this->lstGame->AddItem($objListItem);
        $objGameArray = Videogame::LoadAll();
        if ($objGameArray) foreach ($objGameArray as $objGame) {
            $objListItem = new QListItem($objGame->__toString(), $objGame->IdVideogame);
            $this->lstGame->AddItem($objListItem);
        }
        $this->lstGame->AddAction(new QChangeEvent(), new QAjaxControlAction($this,'lstAll_Change'));

    }

    public function lstStake_Create(){
        $this->lstStake = new QListBox($this);
        $this->lstStake->CssClass = 'drop-down-input';
        $this->lstStake->Name = QApplication::Translate('Apuesta');
        $this->lstStake->Required = false;
        $objListItem = new QListItem(QApplication::Translate("Todos"), null);
        $this->lstStake->AddItem($objListItem);
        $objStakeArray = Videostake::LoadAll();
        if ($objStakeArray) foreach ($objStakeArray as $objStake) {
            $objListItem = new QListItem($objStake->__toString(), $objStake->IdVideostake);
            $this->lstStake->AddItem($objListItem);
        }
        $this->lstStake->AddAction(new QChangeEvent(), new QAjaxControlAction($this,'lstAll_Change'));

    }

    public function lstSite_Create(){
        $this->lstSite = new QListBox($this);
        $this->lstSite->CssClass = 'drop-down-input';
        $this->lstSite->Name = QApplication::Translate('Sitio');
        $this->lstSite->Required = false;
        $objListItem = new QListItem(QApplication::Translate("Todos"), null);
        $this->lstSite->AddItem($objListItem);
        $objSiteArray = Videosite::LoadAll();
        if ($objSiteArray) foreach ($objSiteArray as $objSite) {
            $objListItem = new QListItem($objSite->__toString(), $objSite->IdVideosite);
            $this->lstSite->AddItem($objListItem);
        }
        $this->lstSite->AddAction(new QChangeEvent(), new QAjaxControlAction($this,'lstAll_Change'));

    }

    public function lstTrainer_Create(){
        $this->lstTrainer = new QListBox($this);
        $this->lstTrainer->CssClass = 'drop-down-input';
        $this->lstTrainer->Name = QApplication::Translate('Entrenador');
        $this->lstTrainer->Required = false;
        $objListItem = new QListItem(QApplication::Translate("Todos"), null);
        $this->lstTrainer->AddItem($objListItem);
        $objTrainerArray = Trainer::LoadAll();
        if ($objTrainerArray) foreach ($objTrainerArray as $objTrainer) {
            $objListItem = new QListItem($objTrainer->__toString(), $objTrainer->IdTrainer);
            $this->lstTrainer->AddItem($objListItem);
        }
        $this->lstTrainer->AddAction(new QChangeEvent(), new QAjaxControlAction($this,'lstAll_Change'));

    }
    
    public function btnTagSave_Click(){
        //does the same as the list changes
        $this->lstAll_Change();
    }

    public function lstAll_Change() {
        $this->Refresh();
    }
}


?>