<?php
    /**
	 * Empty event, used internally by QAutoCompleteTextBoxBase.
	 *
	 * @package Events
	 */
	class QAutoCompleteTextBoxEvent extends QEvent {
		protected $strJavaScriptEvent = '';
	}
?>